from django.contrib import admin
from .models import Cliente, Empleado, Producto, Carrito, Categorias, Pedido, Orden_de_compra, Reporte, Pago

# Registrando todos los modelos para que sean gestionables desde el panel de administración
admin.site.register(Cliente)
admin.site.register(Empleado)
admin.site.register(Producto)
admin.site.register(Carrito)
admin.site.register(Categorias)
admin.site.register(Pedido)
admin.site.register(Orden_de_compra)
admin.site.register(Reporte)
admin.site.register(Pago)
